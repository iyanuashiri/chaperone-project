(function(){"use strict";console.log("Content script loaded"),window.chaperoneContentScriptInjected=!0,browser.runtime.onMessage.addListener((a,h,b)=>{console.log("Message received in content script:",a),a.action==="showModal"&&C(a.timeLimit,a.tabId,a.data,a.type)});async function C(a,h,b,w){console.log("Showing modal with challenge data:",b,"type:",w);const y=document.getElementById("chaperone-modal");y&&y.remove();const s=document.createElement("div");s.id="chaperone-modal",s.style.cssText="position: fixed; inset: 0; display: flex; align-items: center; justify-content: center; background-color: rgba(0, 0, 0, 0.5); backdrop-filter: blur(4px); z-index: 2147483647; padding: 1rem;";const l=document.createElement("div");l.style.cssText="background-color: white; border-radius: 0.75rem; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04); width: 100%; max-width: 28rem; overflow: hidden;",s.appendChild(l);function E(){l.innerHTML="";const i=document.createElement("div");i.style.cssText=`
      padding: 1rem;
      border-bottom: 1px solid #e5e7eb;
      background-color: #f9fafb;
    `;const g=document.createElement("h2");g.textContent="Time Limit Reached",g.style.cssText=`
      font-size: 1.25rem;
      font-weight: 600;
      color: #111827;
      margin: 0;
    `,i.appendChild(g),l.appendChild(i);const o=document.createElement("div");o.style.cssText="padding: 1.5rem;";const f=document.createElement("p");f.textContent=`Your time limit of ${a/6e4} minutes has been reached. Solve this to continue:`,f.style.cssText=`
      color: #4b5563;
      margin-bottom: 1rem;
    `,o.appendChild(f);const m=document.createElement("div");m.style.cssText=`
      margin-bottom: 1.5rem;
    `;const x=document.createElement("p");x.textContent="Select the synonym of:",x.style.cssText=`
      color: #4b5563;
      margin-bottom: 0.5rem;
    `;const u=document.createElement("div");u.textContent=b.vocabulary.word,u.style.cssText=`
      font-size: 1.5rem;
      font-weight: 600;
      color: #111827;
      text-align: center;
      padding: 0.5rem;
      border-radius: 0.5rem;
      background-color: #f3f4f6;
    `,m.appendChild(x),m.appendChild(u),o.appendChild(m);const e=document.createElement("div");e.style.cssText=`
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 0.75rem;
      margin-bottom: 1.5rem;
    `,b.options.forEach(r=>{r.is_correct&&r.option}),[...b.options].sort(()=>Math.random()-.5).forEach(r=>{const p=document.createElement("button");p.textContent=r.option,p.style.cssText=`
        padding: 0.75rem;
        border: 1px solid #e5e7eb;
        border-radius: 0.5rem;
        background-color: white;
        color: #374151;
        font-weight: 500;
        transition: all 0.15s ease;
        cursor: pointer;
      `,p.addEventListener("mouseover",()=>{p.style.backgroundColor="#f3f4f6"}),p.addEventListener("mouseout",()=>{p.style.backgroundColor="white"}),p.addEventListener("click",()=>{r.is_correct?(clearTimeout(k),browser.runtime.sendMessage({action:"answerCorrect",associationId:b.id}),v()):(browser.runtime.sendMessage({action:"answerIncorrect",associationId:b.id}),d())}),e.appendChild(p)}),o.appendChild(e);const n=document.createElement("div");n.style.cssText=`
      display: flex;
      gap: 0.75rem;
      justify-content: flex-end;
    `;const t=document.createElement("button");t.textContent="Close Tab",t.style.cssText=`
      background-color: #ef4444;
      color: white;
      padding: 0.75rem 1.5rem;
      border-radius: 0.5rem;
      font-weight: 500;
      transition: background-color 0.15s ease;
      cursor: pointer;
      border: none;
    `,t.addEventListener("mouseover",()=>{t.style.backgroundColor="#dc2626"}),t.addEventListener("mouseout",()=>{t.style.backgroundColor="#ef4444"}),t.addEventListener("click",()=>{browser.runtime.sendMessage({action:"closeTab",tabId:h}),s.remove()}),n.appendChild(t),o.appendChild(n),l.appendChild(o);function d(){let r=s.querySelector(".incorrect-message");r||(r=document.createElement("p"),r.classList.add("incorrect-message"),r.style.cssText=`
          color: #dc2626;
          margin-bottom: 1rem;
          font-size: 0.875rem;
          text-align: center;
        `,e.insertAdjacentElement("afterend",r)),r.textContent="Incorrect answer. Try again."}}function v(){l.innerHTML="";const i=document.createElement("div");i.style.cssText=`
      padding: 1rem;
      border-bottom: 1px solid #e5e7eb;
      background-color: #f9fafb;
    `;const g=document.createElement("h2");g.textContent="Select Postponement Time",g.style.cssText=`
      font-size: 1.25rem;
      font-weight: 600;
      color: #111827;
      margin: 0;
    `,i.appendChild(g),l.appendChild(i);const o=document.createElement("div");o.style.cssText="padding: 1.5rem;";const f=document.createElement("p");f.textContent="How long would you like to postpone?",f.style.cssText=`
      color: #4b5563;
      margin-bottom: 1rem;
    `,o.appendChild(f);const m=document.createElement("div");m.style.cssText=`
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 0.75rem;
      margin-bottom: 1rem;
    `,[1,2,5,10].forEach(t=>{const d=document.createElement("button");d.textContent=`${t} min`,d.style.cssText=`
        padding: 0.75rem;
        border: 1px solid #e5e7eb;
        border-radius: 0.5rem;
        color: #374151;
        font-weight: 500;
        transition: all 0.15s ease;
        cursor: pointer;
        background-color: white;
      `,d.addEventListener("mouseover",()=>{d.style.backgroundColor="#f3f4f6"}),d.addEventListener("mouseout",()=>{d.style.backgroundColor="white"}),d.addEventListener("click",()=>{s.remove(),browser.runtime.sendMessage({action:"postpone",tabId:h,delay:t*6e4})}),m.appendChild(d)}),o.appendChild(m);const u=document.createElement("div");u.style.cssText=`
      display: flex;
      gap: 0.75rem;
      margin-bottom: 1rem;
    `;const e=document.createElement("input");e.type="number",e.placeholder="Custom (min)",e.style.cssText=`
      flex: 1;
      padding: 0.75rem 1rem;
      border: 1px solid #e5e7eb;
      border-radius: 0.5rem;
      font-size: 1rem;
      outline: none;
      transition: border-color 0.15s ease;
    `,e.addEventListener("focus",()=>{e.style.borderColor="#6366f1",e.style.boxShadow="0 0 0 3px rgba(99, 102, 241, 0.1)"}),e.addEventListener("blur",()=>{e.style.borderColor="#e5e7eb",e.style.boxShadow="none"});const c=document.createElement("button");c.textContent="Set",c.style.cssText=`
      background-color: #6366f1;
      color: white;
      padding: 0.75rem 1.5rem;
      border-radius: 0.5rem;
      font-weight: 500;
      transition: background-color 0.15s ease;
      cursor: pointer;
      border: none;
    `,c.addEventListener("mouseover",()=>{c.style.backgroundColor="#4f46e5"}),c.addEventListener("mouseout",()=>{c.style.backgroundColor="#6366f1"}),c.addEventListener("click",()=>{const t=parseInt(e.value,10);!isNaN(t)&&t>0&&(s.remove(),browser.runtime.sendMessage({action:"postpone",tabId:h,delay:t*6e4}))}),u.appendChild(e),u.appendChild(c),o.appendChild(u);const n=document.createElement("button");n.textContent="Close Tab",n.style.cssText=`
      width: 100%;
      background-color: #ef4444;
      color: white;
      padding: 0.75rem 1.5rem;
      border-radius: 0.5rem;
      font-weight: 500;
      transition: background-color 0.15s ease;
      cursor: pointer;
      border: none;
    `,n.addEventListener("mouseover",()=>{n.style.backgroundColor="#dc2626"}),n.addEventListener("mouseout",()=>{n.style.backgroundColor="#ef4444"}),n.addEventListener("click",()=>{browser.runtime.sendMessage({action:"closeTab",tabId:h}),s.remove()}),o.appendChild(n),l.appendChild(o)}document.body.appendChild(s),E();function T(i){browser.runtime.sendMessage({action:"closeTab",tabId:i}),s.remove()}let k=setTimeout(()=>T(h),6e4)}})();
